function LocalChernNumberofSurfaceMagneticHighSpin32TIFilm
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1; d=0.0;
Nz=10;
Mz=0.2;
Ef=0;
knum=200;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0); GammaAdd=Gamma1*Gamma2-Gamma2*Gamma1;
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4+d*GammaAdd;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


Hex=kron(diag([1;zeros(Nz-2,1);-1]),Ezm);
% Hex=kron(diag(repmat([1;-1],Nz/2,1)),Ezm);
Hz=sparse(kron(eye(Nz),Ti)+Hex+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz'));


k=linspace(0,2,knum+1)*pi/a0; k(end)=[];
[kx,ky]=meshgrid(k,k);

ChernNumberZ=zeros(Nz,1);

% delete(gcp('nocreate'));
% parpool('local',30)
tic
for ind=1:numel(kx)
    
    Hk=Hz+kron(eye(Nz),Tx*exp(1i*kx(ind)*a0)+Ty*exp(1i*ky(ind)*a0)+(Tx*exp(1i*kx(ind)*a0)+Ty*exp(1i*ky(ind)*a0))');
    dHkdkx=kron(eye(Nz),1i*a0*(Tx*exp(1i*kx(ind)*a0)-(Tx*exp(1i*kx(ind)*a0))'));
    dHkdky=kron(eye(Nz),1i*a0*(Ty*exp(1i*ky(ind)*a0)-(Ty*exp(1i*ky(ind)*a0))'));
    
    [sta,val]=eig(full(Hk));
    dval=diag(val);
    
    [liebe,~]=find(dval<=Ef);  valbe=dval(liebe);  stabe=sta(:,liebe);
    [lieup,~]=find(dval>Ef);  valup=dval(lieup);  staup=sta(:,lieup);
    [VALUP,VALBE]=meshgrid(valup,valbe);
    
    Xk=(stabe'*(1i*dHkdkx)*staup)./(VALUP-VALBE);
    Yk=(stabe'*(1i*dHkdky)*staup)./(VALUP-VALBE);
    
    ChernNumberZk=zeros(Nz,1);
    for layer=1:Nz
        rhoklayer=stabe((layer-1)*orbitnum+1:layer*orbitnum,:)'*stabe((layer-1)*orbitnum+1:layer*orbitnum,:);
        ChernNumberZk(layer)=trace(Xk*Yk'*rhoklayer);
    end
    
    ChernNumberZ=ChernNumberZ+ChernNumberZk;
    
end
toc

ChernNumberZ=-4.*pi.*imag(ChernNumberZ)./(knum^2.*a0^2)
ChernNumber=sum(ChernNumberZ)
ChernNumber1Z=zeros(Nz,1);
for ii=1:numel(ChernNumberZ)
    ChernNumber1Z(ii)=sum(ChernNumberZ(1:ii));
end


% save(['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'knum',num2str(knum),'.mat'],...
%     'M0','A1','A2','B1','B2','a0','Nz','Mz','Ef','knum','ChernNumberZ','ChernNumber','ChernNumber1Z')

figure,hold on,box on
yyaxis left
Lz=(Nz-1)*a0;
plot((-Lz/2:a0:Lz/2)'./Lz,ChernNumberZ,'-^','DisplayName','C_z')
xlabel('z/L_z'),ylabel('C_z')

yyaxis right
plot((-Lz/2:a0:Lz/2)'./Lz,ChernNumber1Z,'-s','DisplayName','C_z')
ylabel('$\tilde{C}_z$','interpreter','latex')

legend

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_z=',num2str(Nz)];
       ['M_z=',num2str(Mz),', E_f=',num2str(Ef),', kmesh=',num2str(knum),'*',num2str(knum)]})

% saveas(gcf,['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'knum',num2str(knum),'.fig'])
% close(gcf)
% open(['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'knum',num2str(knum),'.fig'])

end