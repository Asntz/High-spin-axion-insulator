function SurfaceEdgeSpectralfunofSurfaceMagneticSemiHighSpinTI32Film
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Ny=30;
Mz=0.6;
eta=1.e-04;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


H00=kron(eye(Ny),Ti)+kron(diag(ones(Ny-1,1),1),Ty)+kron(diag(ones(Ny-1,1),-1),Ty');
H01=kron(eye(Ny),Tz);


knum=501; kx=linspace(-0.5,0.5,knum)*pi/a0; omega=linspace(-0.5,0.5,knum);
[KX,OMEGA]=meshgrid(kx,omega);
AkxomegaL=zeros(size(KX,1),size(KX,2));
AkxomegaR=zeros(size(KX,1),size(KX,2));


delete(gcp('nocreate'))
parpool('local',30)
parfor ind=1:numel(KX)
    ind,tic
    H00k=H00+kron(eye(Ny),Tx*exp(1i*KX(ind)*a0)+(Tx*exp(1i*KX(ind)*a0))');
    
    Trans=[H01\((OMEGA(ind)+1i*eta)*eye(size(H00k,1))-H00k),-H01\(H01');eye(size(H00k,1)),zeros(size(H00k,1))];
    [sta,val]=eig(Trans);
    [~,order]=sort(abs(diag(val)));
    ssta=sta(:,order);
    s2=ssta(1:end/2,1:end/2); s1=ssta(end/2+1:end,1:end/2);
    Greenlayer1=inv((OMEGA(ind)+1i*eta)*eye(size(H00k,1))-H00k-H01*s2/s1);
    
    H00k=H00k+kron(eye(Ny),Ezm);
    Greenlayer0=diag(inv((OMEGA(ind)+1i*eta)*eye(size(H00k,1))-H00k-H01*Greenlayer1*H01'));
    AkxomegaL(ind)=-imag(sum(Greenlayer0(1:orbitnum)))./pi;
    AkxomegaR(ind)=-imag(sum(Greenlayer0(end-orbitnum+1:end)))./pi;
    toc
end


save(['SurfaceEdgeSpectralfunofSurfaceMagneticSemiHighSpinTI32FilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'eta',num2str(eta),'knum',num2str(knum),'.mat'],...
    'M0','A1','A2','B1','B2','a0','Ny','Mz','eta','knum','KX','OMEGA','AkxomegaL','AkxomegaR')


figure
subplot(2,1,1),hold on,box on
h=pcolor(KX*a0/pi,OMEGA,AkxomegaL); set(h,'EdgeColor','none')
colorbar;
xlabel('k_xa_0/\pi')
ylabel('E')
title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0)];
       ['N_y=',num2str(Ny),', M_z=',num2str(Mz),', \eta=',num2str(eta),', kmesh=',num2str(knum),'*',num2str(knum)];
       ['Left surface edge spectral function A_{L}(k_x,E)']})


subplot(2,1,2),hold on,box on
h=pcolor(KX*a0/pi,OMEGA,AkxomegaR); set(h,'EdgeColor','none')
colorbar;
xlabel('k_xa_0/\pi')
ylabel('E')
title(['Right surface edge spectral function A_{R}(k_x,E)'])


saveas(gcf,['SurfaceEdgeSpectralfunofSurfaceMagneticSemiHighSpinTI32FilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'eta',num2str(eta),'knum',num2str(knum),'.fig'])
close(gcf)
open(['SurfaceEdgeSpectralfunofSurfaceMagneticSemiHighSpinTI32FilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'eta',num2str(eta),'knum',num2str(knum),'.fig'])

end