function ChargeZk=IntofChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfield(kx,H00,H01)
format long

global M0 A1 A2 B1 B2 a0 Ny Nz Mz phi0 Ef eta

Hk=H00+H01*exp(1i*kx*a0)+(H01*exp(1i*kx*a0))';

[stak,valk]=eig(Hk);
valk=real(diag(valk));

ChargeZk=transpose(sum(reshape(sum(abs(stak(:,valk<=Ef)).^2,2),size(Hk,1)/Nz,Nz)));


end