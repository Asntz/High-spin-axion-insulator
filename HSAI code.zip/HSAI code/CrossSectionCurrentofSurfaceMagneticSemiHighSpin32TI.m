function CrossSectionCurrentofSurfaceMagneticSemiHighSpin32TI
format long

global M0 A1 A2 B1 B2 a0 Ny Mz Ef eta Layer

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Ny=30;
Mz=0.6;
Ef=0.1;
Layer=150;
eta=1.e-04;

tic
CurrentDensity=integral(@(kx) CrossSectionCurrentDensityofSurfaceMagneticSemiHighSpin32TI(kx),-pi/a0,pi/a0,'ArrayValued',true);
toc

Currentlayer=sum(CurrentDensity,2);
Current=zeros(Layer,1);
for layer=1:Layer
    Current(layer,1)=sum(Currentlayer(1:layer));
end
AverageCurrent=zeros(Layer,1);
for layer=1:Layer
    AverageCurrent(layer,1)=sum(Current(1:layer))/layer;
end
    

save(['CrossSectionCurrentofSurfaceMagneticSemiHighSpin32TIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.mat'],...
    'M0','A1','A2','B1','B2','a0','Ny','Mz','Ef','Layer','eta','Current','AverageCurrent','Currentlayer')

figure
subplot(2,1,1),hold on,box on
plot((1:Layer)',Currentlayer,'DisplayName','J_x(z)')
% scatter((1:Layer)',fittingCurrentlayer,'o','filled')
xlabel('z/a_0')
legend

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0)];
      ['N_y=',num2str(Ny),', M_z=',num2str(Mz),', E_f=',num2str(Ef),', Layer=',num2str(Layer),', \eta=',num2str(eta)]})

subplot(2,1,2),hold on,box on
plot((1:Layer)',Current,'DisplayName','I_x(z)')
plot((1:Layer)',AverageCurrent,'DisplayName','\langleI_x(z)\rangle')
% scatter((1:Layer)',fittingCurrent,'o','filled')
xlabel('z/a_0')
legend

saveas(gcf,['CrossSectionCurrentofSurfaceMagneticSemiHighSpin32TIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.fig'])
close(gcf)
open(['CrossSectionCurrentofSurfaceMagneticSemiHighSpin32TIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.fig'])

end