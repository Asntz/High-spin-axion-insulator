function NonreciprocalConductanceofMagDisorderZSurfaceMagnetHighSpin32AI
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nx=31; Ny=20; Nz=21;
lead1=2:12;  lead3=14:24;   l1=lead1(end)-lead1(1)+1; l3=lead3(end)-lead3(1)+1;
lead2=8:18;  lead4=20:30;   l2=lead2(end)-lead2(1)+1; l4=lead4(end)-lead4(1)+1;
ovlp12=intersect(lead1,lead2);  ovlp14=intersect(lead1,lead4);
ovlp32=intersect(lead3,lead2);  ovlp34=intersect(lead3,lead4);
solo1=setdiff(setdiff(lead1,ovlp12),ovlp14);
solo3=setdiff(setdiff(lead3,ovlp32),ovlp34);
solo2=setdiff(setdiff(lead2,ovlp12),ovlp32);
solo4=setdiff(setdiff(lead4,ovlp14),ovlp34);
vacuum=setdiff(1:Nx,[lead1,lead3,lead2,lead4]);
d1=10; d2=10;
Mz=0.6;
MzW=[1.0,0.3]; configs=10;
Ef=linspace(-0.6,0.6,31);
grl=-1i*1.5;
eta=1.e-04;


tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


Sigmma5=blkdiag(eye(Ny*Nz*orbitnum).*grl,zeros((d1*l1+d2*l2+d1*l3+d2*l4+Ny*Nz)*orbitnum));
Sigmma6=blkdiag(zeros((Ny*Nz+d1*l1+d2*l2+d1*l3+d2*l4)*orbitnum),eye(Ny*Nz*orbitnum).*grl);
Sigmma1=zeros((2*Ny*Nz+d1*l1+d2*l2+d1*l3+d2*l4)*orbitnum);
Sigmma2=zeros((2*Ny*Nz+d1*l1+d2*l2+d1*l3+d2*l4)*orbitnum);
Sigmma3=zeros((2*Ny*Nz+d1*l1+d2*l2+d1*l3+d2*l4)*orbitnum);
Sigmma4=zeros((2*Ny*Nz+d1*l1+d2*l2+d1*l3+d2*l4)*orbitnum);
Loc=Ny*Nz*orbitnum;
for Layer=2:Nx-1
    if ismember(Layer,solo1)
        Sigmma1(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    elseif ismember(Layer,solo2)
        Sigmma2(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
    elseif ismember(Layer,solo3)
        Sigmma3(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    elseif ismember(Layer,solo4)
        Sigmma4(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
    elseif ismember(Layer,ovlp12)
        Sigmma2(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
        Sigmma1(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    elseif ismember(Layer,ovlp14)
        Sigmma4(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
        Sigmma1(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    elseif ismember(Layer,ovlp32)
        Sigmma2(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
        Sigmma3(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    elseif ismember(Layer,ovlp34)
        Sigmma4(Loc+1:Loc+d2*orbitnum,Loc+1:Loc+d2*orbitnum)=eye(d2*orbitnum).*grl;
        Loc=Loc+d2*orbitnum;
        Sigmma3(Loc+1:Loc+d1*orbitnum,Loc+1:Loc+d1*orbitnum)=eye(d1*orbitnum).*grl;
        Loc=Loc+d1*orbitnum;
    else
    end
end
% Sigmma1=sparse(Sigmma1);
% Sigmma2=sparse(Sigmma2);
% Sigmma3=sparse(Sigmma3);
% Sigmma4=sparse(Sigmma4);

gamma1=1i*(Sigmma1-Sigmma1');
gamma2=1i*(Sigmma2-Sigmma2');
gamma3=1i*(Sigmma3-Sigmma3');
gamma4=1i*(Sigmma4-Sigmma4');
gamma5=1i*(Sigmma5-Sigmma5');
gamma6=1i*(Sigmma6-Sigmma6');


H00=kron(eye(Ny),kron(eye(Nz),Ti)+kron(diag([1;zeros(Nz-2,1);-1]),Ezm)+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz'))+...
    kron(diag(ones(Ny-1,1),1),kron(eye(Nz),Ty))+kron(diag(ones(Ny-1,1),-1),kron(eye(Nz),Ty'));
H01=kron(eye(Ny*Nz),Tx);


T13=zeros(size(MzW,2),size(Ef,2)); T31=zeros(size(MzW,2),size(Ef,2));
T24=zeros(size(MzW,2),size(Ef,2)); T42=zeros(size(MzW,2),size(Ef,2));
T56=zeros(size(MzW,2),size(Ef,2)); T65=zeros(size(MzW,2),size(Ef,2));


% delete(gcp('nocreate'));
% parpool('local',31)
for Wind=1:numel(MzW)
    MzWMzW=MzW(Wind)
    
    for config=1:configs
        config,tic
        magneticdisor=(rand(Nx*Ny*Nz,1)-1/2).*MzW(Wind);
%         MagneticDisor=zeros(Nx*Nz*Ny,1);
%         for layerind=1:Ny
%             MagneticDisorlayer=[magneticdisor(2*Nz*(layerind-1)+1:2*Nz*(layerind-1)+Nz),zeros(Nz,Nx-2),magneticdisor(2*Nz*(layerind-1)+Nz+1:2*Nz*(layerind-1)+2*Nz)]';
%             MagneticDisor((layerind-1)*Nx*Nz+1:layerind*Nx*Nz)=MagneticDisorlayer(:);
%         end
        
        for ii=1:numel(Ef)
            EfEf=Ef(ii)
            HH00=H00;
            HH01=H01;
            
            gr22=inv((Ef(ii)+1i*eta)*eye(size(HH00,1))-HH00-kron(diag(magneticdisor(Ny*Nz+1:2*Ny*Nz)),kron(sz,tau0)));
            gr11=inv((Ef(ii)+1i*eta)*eye(size(HH00,1))-HH00-kron(diag(magneticdisor(1:Ny*Nz)),kron(sz,tau0)));
            Gr22=inv((Ef(ii)+1i*eta)*eye(size(HH00,1))-HH00-kron(diag(magneticdisor(Ny*Nz+1:2*Ny*Nz)),kron(sz,tau0))-HH01'*gr11*HH01);
            Gr12=gr11*HH01*Gr22;
            Gr11=inv(inv(gr11)-HH01*gr22*HH01');
            Gr21=gr22*HH01'*Gr11;
            gr11=[Gr11,Gr12;Gr21,Gr22];
            for layer=2:Nx-1
                gr22=inv((Ef(ii)+1i*eta)*eye(size(HH00,1))-HH00-kron(diag(magneticdisor(layer*Ny*Nz+1:(layer+1)*Ny*Nz)),kron(sz,tau0)));
                leng=size(gr11,1)-size(gr22,1);
                H12=[zeros(leng,Ny*Nz*orbitnum);HH01];
                Gr22=inv((Ef(ii)+1i*eta)*eye(size(HH00,1))-HH00-kron(diag(magneticdisor(layer*Ny*Nz+1:(layer+1)*Ny*Nz)),kron(sz,tau0))-H12'*gr11*H12);
                Gr12=gr11*H12*Gr22;
                Gr11=inv(inv(gr11)-H12*gr22*H12');
                Gr21=gr22*H12'*Gr11;
                
                if ismember(layer,solo1) || ismember(layer,solo3)
                    ind=[1:leng,leng+((Nz-d1)*orbitnum+1:Nz*orbitnum)];
                elseif ismember(layer,solo2) || ismember(layer,solo4)
                    ind=[1:leng,leng+(1:d2*orbitnum)];
                elseif ismember(layer,vacuum)
                    ind=1:leng;
                else
                    ind=[1:leng,leng+[1:d2*orbitnum,(Nz-d1)*orbitnum+1:Nz*orbitnum]];
                end
                
                gr11=[Gr11(ind,ind),Gr12(ind,:);Gr21(:,ind),Gr22];
            end
            
            GrC=inv(inv(gr11)-Sigmma1-Sigmma2-Sigmma3-Sigmma4-Sigmma5-Sigmma6);
            
            T13Ef=trace(gamma1*GrC*gamma3*GrC');
            T31Ef=trace(gamma3*GrC*gamma1*GrC');
            T24Ef=trace(gamma2*GrC*gamma4*GrC');
            T42Ef=trace(gamma4*GrC*gamma2*GrC');
            T56Ef=trace(gamma5*GrC*gamma6*GrC');
            T65Ef=trace(gamma6*GrC*gamma5*GrC');
            
            
            T13(Wind,ii)=T13(Wind,ii)+T13Ef;
            T31(Wind,ii)=T31(Wind,ii)+T31Ef;
            T24(Wind,ii)=T24(Wind,ii)+T24Ef;
            T42(Wind,ii)=T42(Wind,ii)+T42Ef;
            T56(Wind,ii)=T56(Wind,ii)+T56Ef;
            T65(Wind,ii)=T65(Wind,ii)+T65Ef;
            
            T31NonreEfEf=(T31(Wind,ii)-T13(Wind,ii))/config
            T42NonreEfEf=(T42(Wind,ii)-T24(Wind,ii))/config
            T65NonreEfEf=(T65(Wind,ii)-T56(Wind,ii))/config
        end
        
        toc
    end
    
    T13(Wind,:)=T13(Wind,:)./configs;
    T31(Wind,:)=T31(Wind,:)./configs;
    T24(Wind,:)=T24(Wind,:)./configs;
    T42(Wind,:)=T42(Wind,:)./configs;
    T56(Wind,:)=T56(Wind,:)./configs;
    T65(Wind,:)=T65(Wind,:)./configs;
    
    
    save(['NonreciprocalConductanceofMagDisorderZSurfaceMagnetHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nx',num2str(Nx),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'configs',num2str(configs),'grl',num2str(grl),'eta',num2str(eta),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nx','Ny','Nz','lead1','lead2','lead3','lead4','d1','d2','Mz','MzW','configs','Ef','grl','eta','T13','T31','T24','T42','T56','T65')
end


figure,hold on,box on
plot(Ef,T31-T13,'b-o','DisplayName','G^{N}_{31}')
plot(Ef,T42-T24,'r-s','DisplayName','G^{N}_{42}')
plot(Ef,T65-T56,'g-^','DisplayName','G^{N}_{65}')
xlabel('E_{F}')
ylabel('G^{N}_{ij} (e^2/h)')
legend

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_x=',num2str(Nx),', N_y=',num2str(Ny),', N_z=',num2str(Nz),', M_z=',num2str(Mz),', grl=',num2str(grl)];
       ['d_1=',num2str(d1),', d_2=',num2str(d2),', lead1=',num2str(lead1(1)),'--',num2str(lead1(end)),', lead2=',num2str(lead2(1)),'--',num2str(lead2(end)),', lead3=',num2str(lead3(1)),'--',num2str(lead3(end)),...
       ', lead4=',num2str(lead4(1)),'--',num2str(lead4(end))];
       ['MzW=(',num2str(MzW),'), configurations=',num2str(configs),', \eta=',num2str(eta)]})

saveas(gcf,['NonreciprocalConductanceofMagDisorderZSurfaceMagnetHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nx',num2str(Nx),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'configs',num2str(configs),'grl',num2str(grl),'eta',num2str(eta),'.fig'])
close(gcf)
open(['NonreciprocalConductanceofMagDisorderZSurfaceMagnetHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nx',num2str(Nx),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'configs',num2str(configs),'grl',num2str(grl),'eta',num2str(eta),'.fig'])

end