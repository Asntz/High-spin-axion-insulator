function ChernNumberZ=LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithBfield(H00nonmag,H01xnonmag,H01ynonmag)
format long

global M0 A1 A2 B1 B2 a0 Ny Nz Mz phi0 Ef eta

knum=200;
orbitnum=8;

k=linspace(0,2,knum+1)*pi/a0; k(end)=[];
[kx,ky]=meshgrid(k,k);


ChernNumberZ=zeros(Nz,1);

delete(gcp('nocreate'));
parpool('local',16)
parfor ind=1:numel(kx)
    
    Hk=H00nonmag+H01xnonmag*exp(1i*kx(ind)*a0)+H01ynonmag*exp(1i*ky(ind)*a0)+(H01xnonmag*exp(1i*kx(ind)*a0)+H01ynonmag*exp(1i*ky(ind)*a0))';
    dHkdkx=1i*a0*(H01xnonmag*exp(1i*kx(ind)*a0)-(H01xnonmag*exp(1i*kx(ind)*a0))');
    dHkdky=1i*a0*(H01ynonmag*exp(1i*ky(ind)*a0)-(H01ynonmag*exp(1i*ky(ind)*a0))');
    
    [sta,val]=eig(Hk);
    dval=real(diag(val));
    
    [liebe,~]=find(dval<=Ef);  valbe=dval(liebe);  stabe=sta(:,liebe);
    [lieup,~]=find(dval>Ef);   valup=dval(lieup);  staup=sta(:,lieup);
    [VALUP,VALBE]=meshgrid(valup,valbe);
    
    Xk=(stabe'*(1i*dHkdkx)*staup)./(VALUP-VALBE);
    Yk=(stabe'*(1i*dHkdky)*staup)./(VALUP-VALBE);
    
    ChernNumberZk=zeros(Nz,1);
    for layer=1:Nz
        rhoklayer=stabe((layer-1)*orbitnum+1:layer*orbitnum,:)'*stabe((layer-1)*orbitnum+1:layer*orbitnum,:);
        ChernNumberZk(layer)=trace(Xk*Yk'*rhoklayer);
    end
    
    ChernNumberZ=ChernNumberZ+ChernNumberZk;
    
end

ChernNumberZ=-4.*pi.*imag(ChernNumberZ)./(knum^2.*a0^2);
ChernNumber=sum(ChernNumberZ);
ChernNumber1Z=zeros(Nz,1);
for ii=1:numel(ChernNumberZ)
    ChernNumber1Z(ii)=sum(ChernNumberZ(1:ii));
end

delete(gcp('nocreate'));

end