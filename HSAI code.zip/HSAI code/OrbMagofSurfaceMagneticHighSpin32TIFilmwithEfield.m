function OrbMagofSurfaceMagneticHighSpin32TIFilmwithEfield
format long

global M0 A1 A2 B1 B2 a0 Nz Mz Ef

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=20;
Mz=0.6;
Ef=0;
Ez=linspace(0,5.e-03/((Nz-1)*a0),6);  %Ez is actually Ez*e


OrbMz=zeros(size(Ez));  %OrbMz is actually OrbMz/(e/2h)
for ind=1:numel(Ez)
    tic
    dtU=Ez(ind)*(Nz-1)*a0
    
    OrbMz(ind)=-2*integral2(@(KX,KY) arrayfun(@(kx,ky) IntofOrbMagofSurfaceMagneticHighSpin32TIFilmwithEfield(Ez(ind),kx,ky),KX,KY),-pi,pi,-pi,pi)./(2*pi);
    OrbMzdtU=OrbMz(ind)
    
    
    save(['OrbMagofSurfaceMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nz','Mz','Ef','Ez','OrbMz')
    
    figure,hold on,box on
    plot(Ez.*(Nz-1)*a0.*1000,OrbMz*1000,'b-s','DisplayName','M_{orb}')
    plot(Ez.*(Nz-1)*a0.*1000,4.*Ez.*(Nz-1)*a0.*1000,'-k','DisplayName','IC')
    xlabel('\deltaU (10^{-3})'),ylabel('M_{orb} (10^{-3}\cdote/2h)')
    legend
    
    title(['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_z=',num2str(Nz),', M_z=',num2str(Mz),', E_f=',num2str(Ef)])
    
    saveas(gcf,['OrbMagofSurfaceMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'.fig'])
    close(gcf)
    
    toc
end

open(['OrbMagofSurfaceMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'Ef',num2str(Ef),'.fig'])

end