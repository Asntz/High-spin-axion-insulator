function DetectionofNonreciprocalConductanceofSurfaceMagHighSpin32TIFilm
format long

G13=2.5;
G31=4.5;
V0=1.0;
w0=pi;
NumofPeriod=20;


tin1period=linspace(0,1,5001)*2*pi/w0;
t=[];
% for ii=-NumofPeriod/2:NumofPeriod/2-1
%     t=[t,ii*2*pi/w0+tin1period];
% end
for ii=0:NumofPeriod-1
    t=[t,ii*2*pi/w0+tin1period];
end

it=zeros(size(t));
for ind=1:numel(t)
    i_t=sin(w0*t(ind));
    if i_t>0
        it(ind)=-G31*V0*i_t;
    else
        it(ind)=-G13*V0*i_t;
    end
end


% w=linspace(-8,8,161)*w0;
w=linspace(0,8,161)*w0;
Fw=zeros(size(w));
tic
for ind=1:numel(w)
    Ft=it.*exp(-1i.*w(ind).*t);
    %Iw(ind)=real(trapz(t,Ft))./NumofPeriod./V;
    Fw(ind)=abs(trapz(t,Ft))./NumofPeriod./V0.*abs(w0^2-w(ind)^2)./(2.*w0);
end
toc


save(['DetectionofNonreciprocalConductanceofSurfaceMagHighSpin32TIFilmG13',num2str(G13),'G31',num2str(G31),'V0',num2str(V0),'w0',num2str(w0/pi),'NumofPeriod',num2str(NumofPeriod),'.mat'],...
    'G13','G31','V0','w0','NumofPeriod','t','it','w','Fw')

figure
subplot(2,1,1),box on,hold on
plot(t.*w0./(2*pi),it)
xlabel('t/(2\pi/\omega_0)'),ylabel('i/(V_0e^2/h)')

title(['s=3/2',', G_{13}=',num2str(G13),'e^2/h',', G_{31}=',num2str(G31),'e^2/h',', V_0=',num2str(V0),', \omega_0=',num2str(w0),', NumofPeriod=',num2str(NumofPeriod)])

subplot(2,1,2),box on,hold on
plot(w./w0,Fw)
%xlabel('\omega/\omega_0'),ylabel('I(\omega)/(Ne^2V/h)')
xlabel('\omega/\omega_0'),ylabel('F(\omega)')

saveas(gcf,['DetectionofNonreciprocalConductanceofSurfaceMagHighSpin32TIFilmG13',num2str(G13),'G31',num2str(G31),'V0',num2str(V0),'w0',num2str(w0/pi),'NumofPeriod',num2str(NumofPeriod),'.fig'])
close(gcf)
open(['DetectionofNonreciprocalConductanceofSurfaceMagHighSpin32TIFilmG13',num2str(G13),'G31',num2str(G31),'V0',num2str(V0),'w0',num2str(w0/pi),'NumofPeriod',num2str(NumofPeriod),'.fig'])

end