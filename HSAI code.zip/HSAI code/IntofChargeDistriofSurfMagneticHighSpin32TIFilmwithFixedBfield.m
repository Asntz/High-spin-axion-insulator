function ChargeZk=IntofChargeDistriofSurfMagneticHighSpin32TIFilmwithFixedBfield(kx,H00,H01,Nz)
format long

global M0 A1 A2 B1 B2 a0 Ny Mz phi0 Ef eta

Hk=H00+H01*exp(1i*kx*a0)+(H01*exp(1i*kx*a0))';

[stak,valk]=eig(Hk);
valk=real(diag(valk));

ChargeZk=transpose(sum(reshape(sum(abs(stak(:,valk<=Ef)).^2,2),size(Hk,1)/Nz,Nz)));

end