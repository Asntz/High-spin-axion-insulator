function ChernNumberofHybridWannierCenterofSurfMagneticHighSpin52TIFilm
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=4:4:60;
Mz=0.6;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(6);
sx=[0,sqrt(5),0,0,0,0;
    sqrt(5),0,sqrt(8),0,0,0;
    0,sqrt(8),0,sqrt(9),0,0;
    0,0,sqrt(9),0,sqrt(8),0;
    0,0,0,sqrt(8),0,sqrt(5);
    0,0,0,0,sqrt(5),0]/2;
sy=[0,sqrt(5),0,0,0,0;
    -sqrt(5),0,sqrt(8),0,0,0;
    0,-sqrt(8),0,sqrt(9),0,0;
    0,0,-sqrt(9),0,sqrt(8),0;
    0,0,0,-sqrt(8),0,sqrt(5);
    0,0,0,0,-sqrt(5),0]/(2*1i);
sz=[5/2,0,0,0,0,0;0,3/2,0,0,0,0;0,0,1/2,0,0,0;0,0,0,-1/2,0,0;0,0,0,0,-3/2,0;0,0,0,0,0,-5/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=12;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


a1=[a0;0];      a2=[0;a0];
b1=[2*pi/a0,0]; b2=[0,2*pi/a0];


knum=200;
kk=linspace(0,2,knum+1)*pi/a0; kk(end)=[];
[kx,ky]=meshgrid(kk,kk);


ChernNumber=zeros(2,numel(Nz));

delete(gcp('nocreate'));
parpool('local',30)
for ind=1:numel(Nz)
    tic
    NzNz=Nz(ind)
    
    Hex=kron(diag([1;zeros(NzNz-2,1);-1]),Ezm);
    Hz=kron(eye(NzNz),Ti)+Hex+kron(diag(ones(NzNz-1,1),1),Tz)+kron(diag(ones(NzNz-1,1),-1),Tz');
    
    HWCCGroup1=1:2; HWCCGroup2=orbitnum*NzNz/2-1:orbitnum*NzNz/2-0;
    
    BerryPhase1=0; BerryPhase2=0;
    parfor kind=1:numel(kx)
        k=[kx(kind),ky(kind)];
        
        Hk=Hz+kron(eye(NzNz),Tx*exp(1i*k(1)*a0)+Ty*exp(1i*k(2)*a0)+(Tx*exp(1i*k(1)*a0)+Ty*exp(1i*k(2)*a0))');
        
        [stak,valk]=eig(Hk);
        [valk,order]=sort(real(diag(valk)));
        stak=stak(:,order);
        
        stakocc=stak(:,1:end/2);
        Lz=(NzNz-1)*a0;
        pzpk=(stakocc')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stakocc;
        
        [hwfk,hwck]=eig(pzpk);
        [hwck,order]=sort(real(diag(hwck)));
        hwfk=hwfk(:,order);
        hwfkinorbit=transpose(transpose(hwfk)*transpose(stakocc));
        
        %%----------------------------------------------------------------------------------------------------------------------------------------------------------
        k1=k+b1/knum;
        
        Hk1=Hz+kron(eye(NzNz),Tx*exp(1i*k1(1)*a0)+Ty*exp(1i*k1(2)*a0)+(Tx*exp(1i*k1(1)*a0)+Ty*exp(1i*k1(2)*a0))');
        
        [stak1,valk1]=eig(Hk1);
        [valk1,order]=sort(real(diag(valk1)));
        stak1=stak1(:,order);
        
        stak1occ=stak1(:,1:end/2);
        pzpk1=(stak1occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stak1occ;
        
        [hwfk1,hwck1]=eig(pzpk1);
        [hwck1,order]=sort(real(diag(hwck1)));
        hwfk1=hwfk1(:,order);
        hwfk1inorbit=transpose(transpose(hwfk1)*transpose(stak1occ));
        
        %%----------------------------------------------------------------------------------------------------------------------------------------------------------
        k2=k+b1/knum+b2/knum;
        
        Hk2=Hz+kron(eye(NzNz),Tx*exp(1i*k2(1)*a0)+Ty*exp(1i*k2(2)*a0)+(Tx*exp(1i*k2(1)*a0)+Ty*exp(1i*k2(2)*a0))');
        
        [stak2,valk2]=eig(Hk2);
        [valk2,order]=sort(real(diag(valk2)));
        stak2=stak2(:,order);
        
        stak2occ=stak2(:,1:end/2);
        pzpk2=(stak2occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stak2occ;
        
        [hwfk2,hwck2]=eig(pzpk2);
        [hwck2,order]=sort(real(diag(hwck2)));
        hwfk2=hwfk2(:,order);
        hwfk2inorbit=transpose(transpose(hwfk2)*transpose(stak2occ));
        
        %%----------------------------------------------------------------------------------------------------------------------------------------------------------- 
        k3=k+b2/knum;
        
        Hk3=Hz+kron(eye(NzNz),Tx*exp(1i*k3(1)*a0)+Ty*exp(1i*k3(2)*a0)+(Tx*exp(1i*k3(1)*a0)+Ty*exp(1i*k3(2)*a0))');
        
        [stak3,valk3]=eig(Hk3);
        [valk3,order]=sort(real(diag(valk3)));
        stak3=stak3(:,order);
        
        stak3occ=stak3(:,1:end/2);
        pzpk3=(stak3occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stak3occ;
        
        [hwfk3,hwck3]=eig(pzpk3);
        [hwck3,order]=sort(real(diag(hwck3)));
        hwfk3=hwfk3(:,order);
        hwfk3inorbit=transpose(transpose(hwfk3)*transpose(stak3occ));
        
        %%----------------------------------------------------------------------------------------------------------------------------------------------------
        
        BerryPhase1=BerryPhase1-imag(log(det(hwfkinorbit(:,HWCCGroup1)'*hwfk1inorbit(:,HWCCGroup1)*hwfk1inorbit(:,HWCCGroup1)'*hwfk2inorbit(:,HWCCGroup1)*...
            hwfk2inorbit(:,HWCCGroup1)'*hwfk3inorbit(:,HWCCGroup1)*hwfk3inorbit(:,HWCCGroup1)'*hwfkinorbit(:,HWCCGroup1))));
        
        BerryPhase2=BerryPhase2-imag(log(det(hwfkinorbit(:,HWCCGroup2)'*hwfk1inorbit(:,HWCCGroup2)*hwfk1inorbit(:,HWCCGroup2)'*hwfk2inorbit(:,HWCCGroup2)*...
            hwfk2inorbit(:,HWCCGroup2)'*hwfk3inorbit(:,HWCCGroup2)*hwfk3inorbit(:,HWCCGroup2)'*hwfkinorbit(:,HWCCGroup2))));
        
    end
    
    ChernNumber(:,ind)=[BerryPhase1;BerryPhase2]./(2*pi);
    ChernNumberNzNz=ChernNumber(:,ind)
    
    
    save(['ChernNumberofHybridWannierCenterofSurfMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nz','Mz','knum','HWCCGroup1','HWCCGroup2','ChernNumber')
    
    figure,hold on,box on
    plot(1./((Nz-1)*a0),ChernNumber(1,:),'g-o','DisplayName','C^{bot}_{HWF}')
    plot(1./((Nz-1)*a0),ChernNumber(2,:),'b-s','DisplayName','C^{top}_{HWF}')
    xlabel('1/L_z'),ylabel('C^{bot/top}_{HWF}')
    legend
    
    title({['spin=5/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', M_z=',num2str(Mz)];
        ['kmesh=',num2str(knum),'*',num2str(knum),', HWCCGroup1=(',num2str(HWCCGroup1),'), HWCCGroup2=(',num2str(HWCCGroup2),')']})
    
    saveas(gcf,['ChernNumberofHybridWannierCenterofSurfMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])
    close(gcf)
    
    toc
end

open(['ChernNumberofHybridWannierCenterofSurfMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])

end