function Intgrand=IntofOrbMagofCantedSurfMagneticHighSpin32TIFilmwithEfield(Beta,kx,ky)
format long

global M0 A1 A2 B1 B2 a0 Nz M Ef dtV

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0); Gamma6=kron(sx,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);


Exbot=M*sin(Beta)*Gamma6+M*cos(Beta)*Gamma5;
Extop=M*sin(pi-Beta)*Gamma6+M*cos(pi-Beta)*Gamma5;

Hex=kron(diag([1;zeros(Nz-1,1)]),Exbot)+kron(diag([zeros(Nz-1,1);1]),Extop);

Ez=dtV/((Nz-1)*a0);
V=Ez*(0:Nz-1)*a0;  %unit eV.
H0=kron(eye(Nz),Ti)+Hex+kron(diag(V),eye(orbitnum))+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz');

Hk=H0+kron(eye(Nz),Tx*exp(1i*kx*a0)+Ty*exp(1i*ky*a0)+(Tx*exp(1i*kx*a0)+Ty*exp(1i*ky*a0))');
dHkdkx=kron(eye(Nz),1i*(Tx*exp(1i*kx*a0)-(Tx*exp(1i*kx*a0))'));
dHkdky=kron(eye(Nz),1i*(Ty*exp(1i*ky*a0)-(Ty*exp(1i*ky*a0))'));

[sta,val]=eig(Hk);
dval=diag(real(val));

[liebe,~]=find(dval<=Ef);  valbe=dval(liebe);  stabe=sta(:,liebe);
[lieup,~]=find(dval>Ef);   valup=dval(lieup);  staup=sta(:,lieup);
[VALUP,VALBE]=meshgrid(valup,valbe);

Intgrand=sum(sum((VALBE+VALUP-2*Ef)./(VALBE-VALUP).^2.*imag((stabe'*dHkdky*staup).*transpose(staup'*dHkdkx*stabe))));

end