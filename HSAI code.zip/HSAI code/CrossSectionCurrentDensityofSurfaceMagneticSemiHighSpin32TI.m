function CurrentDensity_kx=CrossSectionCurrentDensityofSurfaceMagneticSemiHighSpin32TI(kx)
format long

global M0 A1 A2 B1 B2 a0 Ny Mz Ef eta Layer

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


H00=kron(eye(Ny),Ti+Tx*exp(1i*kx*a0)+(Tx*exp(1i*kx*a0))')+kron(diag(ones(Ny-1,1),1),Ty)+kron(diag(ones(Ny-1,1),-1),Ty');
H01=kron(eye(Ny),Tz);
dH00dkx=kron(eye(Ny),1i*a0*(Tx*exp(1i*kx*a0)-(Tx*exp(1i*kx*a0))'));


Trans=[H01\((Ef+1i*eta)*eye(size(H00,1))-H00),-H01\(H01');eye(size(H00,1)),zeros(size(H00,1))];
[sta,val]=eig(Trans);
[vval,order]=sort(abs(diag(val)));
ssta=sta(:,order);
s2=ssta(1:end/2,1:end/2); s1=ssta(end/2+1:end,1:end/2);
Sigmma=H01*s2/s1;

Grsurf=inv((Ef+1i*eta)*eye(size(H00,1))-H00-Sigmma);


CurrentDensity_kx=zeros(Layer,Ny/2);

Flayer=inv((Ef+1i*eta)*eye(size(H00,1))-H00-kron(eye(Ny),Ezm));
Grlayer=inv((Ef+1i*eta)*eye(size(H00,1))-H00-kron(eye(Ny),Ezm)-H01*Grsurf*H01');
CurrentDensity_kx(1,:)=-imag(sum(reshape(diag(dH00dkx(1:end/2,1:end/2)*Grlayer(1:end/2,1:end/2)),orbitnum,Ny/2)))./(pi);


for layer=2:Layer
    Sigmmadown=H01'*Flayer*H01;
    Flayer=inv((Ef+1i*eta)*eye(size(H00,1))-H00-Sigmmadown);
    Grlayer=inv((Ef+1i*eta)*eye(size(H00,1))-H00-Sigmmadown-Sigmma);
    CurrentDensity_kx(layer,:)=-imag(sum(reshape(diag(dH00dkx(1:end/2,1:end/2)*Grlayer(1:end/2,1:end/2)),orbitnum,Ny/2)))./(pi);
end

end