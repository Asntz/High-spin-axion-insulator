function BandofHighSpin32TIFilm
format long

M0=1; A1=0.5; A2=0.5; B1=1; B2=1; a0=1;
Nz=20;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);


Hz=kron(eye(Nz),Ti)+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz');
Hx=kron(eye(Nz),Tx);
Hy=kron(eye(Nz),Ty);


knum=1000;
kx1=linspace(1,1/knum,knum)*pi/a0;
kx2=linspace(0,1,knum+1)*pi/a0;
kx=[kx1,kx2];
% kx=linspace(-0.8,0.8,knum)*pi/a0;

ky1=0*kx1;
ky2=kx2;
ky=[ky1,ky2];
% ky=0*kx;

Enk=zeros(orbitnum*Nz,numel(kx));

tic
for ind=1:numel(kx)
    Hxy=Hx*exp(1i*kx(ind)*a0)+Hy*exp(1i*ky(ind)*a0)+(Hx*exp(1i*kx(ind)*a0)+Hy*exp(1i*ky(ind)*a0))';
    Hk=Hz+Hxy;
    Enk(:,ind)=sort(real(eig(Hk)));
end
toc


% save(['BandofHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'.mat'],...
%     'M0','A1','A2','B1','B2','a0','Nz','kx','ky','Enk')

figure,hold on,box on
plot([-sqrt(kx1.^2+ky1.^2),sqrt(kx2.^2+ky2.^2)],Enk(end/2-59:end/2+60,:),'k','LineWidth',1.0)
% plot(kx,Enk(end/2-39:end/2+40,:),'k','LineWidth',1.0)

xlabel('k'), ylabel('E_n(k)')
title(['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_z=',num2str(Nz)])
axis([-sqrt(kx1(1).^2+ky1(1).^2),sqrt(kx2(end).^2+ky2(end).^2),-0.8,0.8])


% saveas(gcf,['BandofHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'.fig'])
% close(gcf)
% open(['BandofHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'.fig'])

end