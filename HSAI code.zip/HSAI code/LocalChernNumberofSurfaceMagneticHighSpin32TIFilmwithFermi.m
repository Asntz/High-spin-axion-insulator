function LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithFermi
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=20;
Mz=0.6;
Ef=linspace(-0.5,0.5,101);
knum=200;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


Hz=sparse(kron(eye(Nz),Ti)+kron(diag([1;zeros(Nz-2,1);-1]),Ezm)+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz'));


k=linspace(0,2,knum+1)*pi/a0; k(end)=[];
[kx,ky]=meshgrid(k,k);

ChernNumberZ=zeros(Nz,numel(Ef));


delete(gcp('nocreate'));
parpool('local',30)
parfor ind=1:numel(kx)
    ind,tic
    Hk=Hz+kron(eye(Nz),Tx*exp(1i*kx(ind)*a0)+Ty*exp(1i*ky(ind)*a0)+(Tx*exp(1i*kx(ind)*a0)+Ty*exp(1i*ky(ind)*a0))');
    dHkdkx=kron(eye(Nz),1i*a0*(Tx*exp(1i*kx(ind)*a0)-(Tx*exp(1i*kx(ind)*a0))'));
    dHkdky=kron(eye(Nz),1i*a0*(Ty*exp(1i*ky(ind)*a0)-(Ty*exp(1i*ky(ind)*a0))'));
    
    [sta,val]=eig(full(Hk));
    dval=diag(val);
    
    CChernNumberZ=zeros(Nz,numel(Ef));
    for Efind=1:numel(Ef)
        EfEf=Ef(Efind);
        
        [liebe,~]=find(dval<=EfEf);  valbe=dval(liebe);  stabe=sta(:,liebe);
        [lieup,~]=find(dval>EfEf);   valup=dval(lieup);  staup=sta(:,lieup);
        [VALUP,VALBE]=meshgrid(valup,valbe);
        
        Xk=(stabe'*(1i*dHkdkx)*staup)./(VALUP-VALBE);
        Yk=(stabe'*(1i*dHkdky)*staup)./(VALUP-VALBE);
        
        ChernNumberZtemp=zeros(Nz,1);
        for layer=1:Nz
            rhoklayer=stabe((layer-1)*orbitnum+1:layer*orbitnum,:)'*stabe((layer-1)*orbitnum+1:layer*orbitnum,:);
            ChernNumberZtemp(layer)=trace(Xk*Yk'*rhoklayer);
        end
        
        CChernNumberZ(:,Efind)=CChernNumberZ(:,Efind)+ChernNumberZtemp;
    end
    
    ChernNumberZ=ChernNumberZ+CChernNumberZ;
    
    toc
end


ChernNumberZ=-4.*pi.*imag(ChernNumberZ)./(knum^2.*a0^2);
ChernNumberBottom=sum(ChernNumberZ(1:end/2,:));
ChernNumberTop=sum(ChernNumberZ(end/2+1:end,:));


save(['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithFermiM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'knum',num2str(knum),'.mat'],...
    'M0','A1','A2','B1','B2','a0','Nz','Mz','Ef','knum','ChernNumberZ','ChernNumberBottom','ChernNumberTop')


figure,hold on,box on
plot(Ef,ChernNumberTop,'r-^','DisplayName','C^{top}_{surf}')
plot(Ef,ChernNumberBottom,'b-s','DisplayName','C^{bot}_{surf}')
xlabel('E_F')
ylabel('C^{top/bot}_{surf}')

legend

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0)];
       ['N_z=',num2str(Nz),', M_z=',num2str(Mz),', kmesh=',num2str(knum),'*',num2str(knum)]})

saveas(gcf,['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithFermiM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])
close(gcf)
open(['LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithFermiM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])

end