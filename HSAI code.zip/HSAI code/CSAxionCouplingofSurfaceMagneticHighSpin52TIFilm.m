function CSAxionCouplingofSurfaceMagneticHighSpin52TIFilm
format long

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=4:4:60;
Mz=0.6;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(6);
sx=[0,sqrt(5),0,0,0,0;
    sqrt(5),0,sqrt(8),0,0,0;
    0,sqrt(8),0,sqrt(9),0,0;
    0,0,sqrt(9),0,sqrt(8),0;
    0,0,0,sqrt(8),0,sqrt(5);
    0,0,0,0,sqrt(5),0]/2;
sy=[0,sqrt(5),0,0,0,0;
    -sqrt(5),0,sqrt(8),0,0,0;
    0,-sqrt(8),0,sqrt(9),0,0;
    0,0,-sqrt(9),0,sqrt(8),0;
    0,0,0,-sqrt(8),0,sqrt(5);
    0,0,0,0,-sqrt(5),0]/(2*1i);
sz=[5/2,0,0,0,0,0;0,3/2,0,0,0,0;0,0,1/2,0,0,0;0,0,0,-1/2,0,0;0,0,0,0,-3/2,0;0,0,0,0,0,-5/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=12;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


a1=[a0;0];      a2=[0;a0];
b1=[2*pi/a0,0]; b2=[0,2*pi/a0];


knum=200;
kk=linspace(0,2,knum+1)*pi/a0; kk(end)=[];
[kx,ky]=meshgrid(kk,kk);


ThetaSlab=zeros(3,numel(Nz));

delete(gcp('nocreate'));
parpool('local',30)
for ind=1:numel(Nz)
    tic
    NzNz=Nz(ind)
    
    Hex=kron(diag([1;zeros(NzNz-2,1);-1]),Ezm);
    Hz=kron(eye(NzNz),Ti)+Hex+kron(diag(ones(NzNz-1,1),1),Tz)+kron(diag(ones(NzNz-1,1),-1),Tz');
    
    HWCCGroup1=[1:2,orbitnum*NzNz/2-1:orbitnum*NzNz/2]; HWCCGroup2=3:orbitnum*NzNz/2-2;
    
    ZOmegak1=0; ZOmegak2=0;
    parfor kind=1:numel(kx)
        k=[kx(kind),ky(kind)];
        
        Hk=Hz+kron(eye(NzNz),Tx*exp(1i*k(1)*a0)+Ty*exp(1i*k(2)*a0)+(Tx*exp(1i*k(1)*a0)+Ty*exp(1i*k(2)*a0))');
        
        [stak,valk]=eig(Hk);
        [valk,order]=sort(real(diag(valk)));
        stak=stak(:,order);
        
        stakocc=stak(:,1:end/2);
        Lz=(NzNz-1)*a0;
        pzpk=(stakocc')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stakocc;
        
        [hwfk,hwck]=eig(pzpk);
        [hwck,order]=sort(real(diag(hwck)));
        hwfk=hwfk(:,order);
        hwfkinorbit=transpose(transpose(hwfk)*transpose(stakocc));
        
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        kx1=k-b1/knum;
        
        Hkx1=Hz+kron(eye(NzNz),Tx*exp(1i*kx1(1)*a0)+Ty*exp(1i*kx1(2)*a0)+(Tx*exp(1i*kx1(1)*a0)+Ty*exp(1i*kx1(2)*a0))');
        
        [stakx1,valkx1]=eig(Hkx1);
        [valkx1,order]=sort(real(diag(valkx1)));
        stakx1=stakx1(:,order);
        
        stakx1occ=stakx1(:,1:end/2);
        pzpkx1=(stakx1occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stakx1occ;
        
        [hwfkx1,hwckx1]=eig(pzpkx1);
        [hwckx1,order]=sort(real(diag(hwckx1)));
        hwfkx1=hwfkx1(:,order);
        hwfkx1inorbit=transpose(transpose(hwfkx1)*transpose(stakx1occ));
        
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        kx2=k+b1/knum;
        
        Hkx2=Hz+kron(eye(NzNz),Tx*exp(1i*kx2(1)*a0)+Ty*exp(1i*kx2(2)*a0)+(Tx*exp(1i*kx2(1)*a0)+Ty*exp(1i*kx2(2)*a0))');
        
        [stakx2,valkx2]=eig(Hkx2);
        [valkx2,order]=sort(real(diag(valkx2)));
        stakx2=stakx2(:,order);
        
        stakx2occ=stakx2(:,1:end/2);
        pzpkx2=(stakx2occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stakx2occ;
        
        [hwfkx2,hwckx2]=eig(pzpkx2);
        [hwckx2,order]=sort(real(diag(hwckx2)));
        hwfkx2=hwfkx2(:,order);
        hwfkx2inorbit=transpose(transpose(hwfkx2)*transpose(stakx2occ));
        
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        ky1=k-b2/knum;
        
        Hky1=Hz+kron(eye(NzNz),Tx*exp(1i*ky1(1)*a0)+Ty*exp(1i*ky1(2)*a0)+(Tx*exp(1i*ky1(1)*a0)+Ty*exp(1i*ky1(2)*a0))');
        
        [staky1,valky1]=eig(Hky1);
        [valky1,order]=sort(real(diag(valky1)));
        staky1=staky1(:,order);
        
        staky1occ=staky1(:,1:end/2);
        pzpky1=(staky1occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*staky1occ;
        
        [hwfky1,hwcky1]=eig(pzpky1);
        [hwcky1,order]=sort(real(diag(hwcky1)));
        hwfky1=hwfky1(:,order);
        hwfky1inorbit=transpose(transpose(hwfky1)*transpose(staky1occ));
        
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        ky2=k+b2/knum;
        
        Hky2=Hz+kron(eye(NzNz),Tx*exp(1i*ky2(1)*a0)+Ty*exp(1i*ky2(2)*a0)+(Tx*exp(1i*ky2(1)*a0)+Ty*exp(1i*ky2(2)*a0))');
        
        [staky2,valky2]=eig(Hky2);
        [valky2,order]=sort(real(diag(valky2)));
        staky2=staky2(:,order);
        
        staky2occ=staky2(:,1:end/2);
        pzpky2=(staky2occ')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*staky2occ;
        
        [hwfky2,hwcky2]=eig(pzpky2);
        [hwcky2,order]=sort(real(diag(hwcky2)));
        hwfky2=hwfky2(:,order);
        hwfky2inorbit=transpose(transpose(hwfky2)*transpose(staky2occ));
        
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        
        Skkx1_1=(hwfkinorbit(:,HWCCGroup1)')*hwfkx1inorbit(:,HWCCGroup1);
        alighwfkx1_1=transpose(transpose(inv(Skkx1_1))*transpose(hwfkx1inorbit(:,HWCCGroup1)));
        Skkx2_1=(hwfkinorbit(:,HWCCGroup1)')*hwfkx2inorbit(:,HWCCGroup1);
        alighwfkx2_1=transpose(transpose(inv(Skkx2_1))*transpose(hwfkx2inorbit(:,HWCCGroup1)));
        
        
        Skky1_1=(hwfkinorbit(:,HWCCGroup1)')*hwfky1inorbit(:,HWCCGroup1);
        alighwfky1_1=transpose(transpose(inv(Skky1_1))*transpose(hwfky1inorbit(:,HWCCGroup1)));
        Skky2_1=(hwfkinorbit(:,HWCCGroup1)')*hwfky2inorbit(:,HWCCGroup1);
        alighwfky2_1=transpose(transpose(inv(Skky2_1))*transpose(hwfky2inorbit(:,HWCCGroup1)));
        
        
        dhwfkdkx_1=(alighwfkx2_1-alighwfkx1_1)./2;
        dhwfkdky_1=(alighwfky2_1-alighwfky1_1)./2;
        
        Omegak1=1i*((dhwfkdkx_1)'*dhwfkdky_1-(dhwfkdky_1)'*dhwfkdkx_1);
        
        ZOmegak1=ZOmegak1+sum(hwck(HWCCGroup1).*diag(Omegak1));
        
        %%-----------------------------------------------------------------------------------------------------------------------------------
        
        Skkx1_2=(hwfkinorbit(:,HWCCGroup2)')*hwfkx1inorbit(:,HWCCGroup2);
        alighwfkx1_2=transpose(transpose(inv(Skkx1_2))*transpose(hwfkx1inorbit(:,HWCCGroup2)));
        Skkx2_2=(hwfkinorbit(:,HWCCGroup2)')*hwfkx2inorbit(:,HWCCGroup2);
        alighwfkx2_2=transpose(transpose(inv(Skkx2_2))*transpose(hwfkx2inorbit(:,HWCCGroup2)));
        
        
        Skky1_2=(hwfkinorbit(:,HWCCGroup2)')*hwfky1inorbit(:,HWCCGroup2);
        alighwfky1_2=transpose(transpose(inv(Skky1_2))*transpose(hwfky1inorbit(:,HWCCGroup2)));
        Skky2_2=(hwfkinorbit(:,HWCCGroup2)')*hwfky2inorbit(:,HWCCGroup2);
        alighwfky2_2=transpose(transpose(inv(Skky2_2))*transpose(hwfky2inorbit(:,HWCCGroup2)));
        
        
        dhwfkdkx_2=(alighwfkx2_2-alighwfkx1_2)./2;
        dhwfkdky_2=(alighwfky2_2-alighwfky1_2)./2;
        
        Omegak2=1i*((dhwfkdkx_2)'*dhwfkdky_2-(dhwfkdky_2)'*dhwfkdkx_2);
        
        ZOmegak2=ZOmegak2+sum(hwck(HWCCGroup2).*diag(Omegak2));
    end
    
    ZOmegak=[ZOmegak1;ZOmegak2];
    ThetaSlab(1:end-1,ind)=-ZOmegak./((NzNz-1)*a0);
    ThetaSlab(end,ind)=sum(ThetaSlab(1:end-1,ind));
    ThetaSlabNzNz=ThetaSlab(:,ind)./pi
    
    
    save(['CSAxionCouplingofSurfaceMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nz','Mz','knum','ThetaSlab')
    
    figure,hold on,box on
    plot(1./((Nz-1)*a0),ThetaSlab(1,:)./pi,'g-o','DisplayName','\theta^{surf}_{CS}/\pi')
    plot(1./((Nz-1)*a0),ThetaSlab(2,:)./pi,'b-^','DisplayName','\theta^{bulk}_{CS}/\pi')
    plot(1./((Nz-1)*a0),ThetaSlab(3,:)./pi,'r-s','DisplayName','\theta^{slab}_{CS}/\pi')
    xlabel('1/L_z'),ylabel('\theta^{surf/bulk/slab}_{CS}/\pi')
    legend
    
    title(['spin=5/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', M_z=',num2str(Mz),', kmesh=',num2str(knum),'*',num2str(knum)])
    
    saveas(gcf,['CSAxionCouplingofSurfaceMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])
    close(gcf)
    
    toc
end

open(['CSAxionCouplingofSurfaceMagneticHighSpin52TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'knum',num2str(knum),'.fig'])

end