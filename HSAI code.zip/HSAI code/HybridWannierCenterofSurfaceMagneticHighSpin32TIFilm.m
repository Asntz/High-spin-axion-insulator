function HybridWannierCenterofSurfaceMagneticHighSpin32TIFilm
format long

M0=1; A1=0.6; A2=A1; B1=1; B2=B1; a0=1;
Nz=20;
Mz=0.3;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


Hex=kron(diag([1;zeros(Nz-2,1);-1]),Ezm);
% Hex=kron(diag(repmat([1;-1],Nz/2,1)),Ezm);
Hz=kron(eye(Nz),Ti)+Hex+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz');
Hx=kron(eye(Nz),Tx);
Hy=kron(eye(Nz),Ty);


knum=100;
kx=[linspace(1,1/knum,knum),linspace(0,1-1/knum,knum),ones(1,knum+1)]*pi/a0;
ky=[linspace(1,1/knum,knum),zeros(1,knum),linspace(0,1,knum+1)]*pi/a0;
Znk=zeros(orbitnum*Nz/2,numel(kx));


% delete(gcp('nocreate'));
% parpool('local',36)
tic
for ind=1:numel(kx)
    Hxy=Hx*exp(1i*kx(ind)*a0)+Hy*exp(1i*ky(ind)*a0)+(Hx*exp(1i*kx(ind)*a0)+Hy*exp(1i*ky(ind)*a0))';
    Hk=Hz+Hxy;
    
    
    [stak,valk]=eig(Hk);
    [valk,order]=sort(real(diag(valk)));
    stak=stak(:,order);
    
    stakocc=stak(:,1:end/2);
    Lz=(Nz-1)*a0;
    pzpk=(stakocc')*diag(kron(-Lz/2:a0:Lz/2,ones(1,orbitnum)))*stakocc;
%     pzpk=(stakocc')*diag(kron(-(Lz-a0)/2:a0:(Lz+a0)/2,ones(1,orbitnum)))*stakocc;
    
    [hwfk,hwck]=eig(pzpk);
    hwck=sort(real(diag(hwck)));
    
    Znk(:,ind)=hwck;
end
toc


% save(['HybridWannierCenterofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'.mat'],...
%     'M0','A1','A2','B1','B2','a0','Nz','Mz','kx','ky','Znk')

figure,hold on,box on
plot([0:sqrt(2)/knum:sqrt(2)-sqrt(2)/knum,sqrt(2):1/knum:sqrt(2)+2],Znk./Lz,'k','LineWidth',1.0)

xlabel('k'), ylabel('Z_{nk}/L_z')
title(['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_z=',num2str(Nz),', M_z=',num2str(Mz)])

% saveas(gcf,['HybridWannierCenterofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'.fig'])
% close(gcf)
% open(['HybridWannierCenterofSurfaceMagneticHighSpin32TIFilmM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'Mz',num2str(Mz),'.fig'])

end