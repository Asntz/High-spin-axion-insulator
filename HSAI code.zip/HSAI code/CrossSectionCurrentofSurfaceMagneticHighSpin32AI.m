function CrossSectionCurrentofSurfaceMagneticHighSpin32AI
format long

global M0 A1 A2 B1 B2 a0 Ny Mz Ef eta Layer

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Ny=30;
Mz=0.6;
Ef=0.1;
Layer=150;
eta=1.e-04;


CurrentDensity=integral(@(kx) CrossSectionCurrentDensityofSurfaceMagneticHighSpin32AI(kx),-pi/a0,pi/a0,'ArrayValued',true);

Currentlayer=sum(CurrentDensity,2);
Current=zeros(Layer,1);
for layer=1:Layer
    if layer-7>=1 && layer+7 <=Layer
        Current(layer,1)=sum(Currentlayer(layer-7:layer+7));
    else
    end
end


save(['CrossSectionCurrentofSurfaceMagneticHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.mat'],...
    'M0','A1','A2','B1','B2','a0','Ny','Mz','Ef','Layer','eta','Current','Currentlayer','CurrentDensity')

figure
subplot(2,1,1),hold on
[Y,Z]=meshgrid(-(Ny-1)*a0/2:a0:-a0/2,-(Layer-1)*a0/2:a0:(Layer-1)*a0/2);
surf(Y,Z,CurrentDensity,'edgecolor','none')
xlabel('y')
ylabel('z')
zlabel('J_{x}(y,z)')
% axis([0,Layer+1,0,Ny/2+1,-2,2])

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0)];
      ['N_y=',num2str(Ny),', M_z=',num2str(Mz),', E_f=',num2str(Ef),', Layer=',num2str(Layer),', \eta=',num2str(eta)]})

subplot(2,1,2),hold on,box on
Lz=(Layer-1)*a0;
plot((-Lz/2:a0:Lz/2)'./Lz,Current,'DisplayName','\langleI_x(z)\rangle_{MA}')
xlabel('z/L_z')
legend

saveas(gcf,['CrossSectionCurrentofSurfaceMagneticHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.fig'])
close(gcf)
open(['CrossSectionCurrentofSurfaceMagneticHighSpin32AIM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'Ef',num2str(Ef),'Layer',num2str(Layer),'eta',num2str(eta),'.fig'])

end