function MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedEfield
format long

global M0 A1 A2 B1 B2 a0 Mz Ef

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=4:4:60;
Mz=0.6;
Ef=0;
dtU=1.e-03;


MagEleCoeff=zeros(size(Nz));  % MagEleCoeff is actually MagEleCoeff/(e^2/2h).
for ind=1:numel(Nz)
    tic
    NzNz=Nz(ind)
    
    Ez=dtU/((NzNz-1)*a0);
    MagEleCoeff(ind)=-2*integral2(@(KX,KY) arrayfun(@(kx,ky) IntofOrbMagofSurfMagneticHighSpin32TIFilmwithFixedEfield(NzNz,Ez,kx,ky),KX,KY),-pi,pi,-pi,pi)./(2*pi*dtU);
    
    MagEleCoeffNzNz=MagEleCoeff(ind)
    
    
    save(['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'Ef',num2str(Ef),'dtU',num2str(dtU),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nz','Mz','Ef','dtU','MagEleCoeff')
    
    figure,hold on,box on
    plot(1./((Nz-1)*a0),MagEleCoeff,'b-s')
    xlabel('1/L_z'),ylabel('M_{orb}/(\deltaU\cdote/2h)')
    
    title(['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', M_z=',num2str(Mz),', E_f=',num2str(Ef),', \deltaU=',num2str(dtU)])
    
    saveas(gcf,['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'Ef',num2str(Ef),'dtU',num2str(dtU),'.fig'])
    close(gcf)
    
    toc
end

open(['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Mz',num2str(Mz),'Ef',num2str(Ef),'dtU',num2str(dtU),'.fig'])

end