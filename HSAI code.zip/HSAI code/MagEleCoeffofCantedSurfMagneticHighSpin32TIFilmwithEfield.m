function MagEleCoeffofCantedSurfMagneticHighSpin32TIFilmwithEfield
format long

global M0 A1 A2 B1 B2 a0 Nz M Ef dtV

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Nz=20;
M=0.6;  Beta=[linspace(0,0.24,7),linspace(0.26,0.46,6),linspace(0.47,0.5,4)]*pi; %Beta(Beta/pi<0.42)=[];
Ef=0;
dtV=1.e-03;  %unit eV.


MagEleCoeff=zeros(size(Beta));  %MagEleCoeff is actually OrbMag/(e/h)/dtV, unit eV.
for ind=1:numel(Beta)
    tic
    BetaBeta=Beta(ind)/pi
    
    MagEleCoeff(ind)=-2*integral2(@(KX,KY) arrayfun(@(kx,ky) IntofOrbMagofCantedSurfMagneticHighSpin32TIFilmwithEfield(Beta(ind),kx,ky),KX,KY),-pi,pi,-pi,pi)./(2*pi*dtV);
    MagEleCoeffBetaBeta=MagEleCoeff(ind)
    
    
    save(['MagEleCoeffofCantedSurfMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'M',num2str(M),'Ef',num2str(Ef),'dtV',num2str(dtV),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Nz','M','Beta','Ef','dtV','MagEleCoeff')
    
    figure,hold on,box on
    plot(Beta./pi,MagEleCoeff,'b-o')
    xlabel('\beta/\pi'),ylabel('M/\alpha\delta U')
    
    title(['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_z=',num2str(Nz),', M=',num2str(M),', E_f=',num2str(Ef),', \delta V=',num2str(dtV)])
    
    saveas(gcf,['MagEleCoeffofCantedSurfMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'M',num2str(M),'Ef',num2str(Ef),'dtV',num2str(dtV),'.fig'])
    close(gcf)
    
    toc
end

open(['MagEleCoeffofCantedSurfMagneticHighSpin32TIFilmwithEfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Nz',num2str(Nz),'M',num2str(M),'Ef',num2str(Ef),'dtV',num2str(dtV),'.fig'])

end