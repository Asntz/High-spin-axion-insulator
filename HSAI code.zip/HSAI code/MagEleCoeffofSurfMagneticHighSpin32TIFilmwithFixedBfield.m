function MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedBfield
format long

global M0 A1 A2 B1 B2 a0 Ny Mz phi0 Ef eta

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Ny=100; Nz=4:4:60;
Mz=0.6;
phi0=0.01; % Unit h/e.
Ef=0;
eta=1.e-04;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


ChargedensityZ=zeros(max(Nz),size(Nz,2));
Polarization=zeros(1,size(Nz,2));
Magnetoelectric=zeros(1,size(Nz,2));


for ind=1:numel(Nz)
    tic
    NzNz=Nz(ind)
    
    H00=kron(eye(NzNz),kron(eye(Ny),Ti)+kron(diag(ones(Ny-1,1),1),Ty)+kron(diag(ones(Ny-1,1),-1),Ty'))+...
        kron(diag(ones(NzNz-1,1),1),kron(eye(Ny),Tz))+kron(diag(ones(NzNz-1,1),-1),kron(eye(Ny),Tz'))+...
        kron(diag([ones(Ny,1);zeros(Ny*(NzNz-2),1);-ones(Ny,1)]),Ezm);
    
    H01=kron(eye(NzNz),kron(diag(exp(1i*2*pi*phi0*(1:Ny))),Tx));
    
    ChargedensityZ(1:NzNz,ind)=integral(@(kx) IntofChargeDistriofSurfMagneticHighSpin32TIFilmwithFixedBfield(kx,H00,H01,NzNz),-pi/a0,pi/a0,'ArrayValued',true);
    ChargedensityZ(1:NzNz,ind)=ChargedensityZ(1:NzNz,ind).*a0./(2*pi);
    
    averageChargedensityZ=sum(ChargedensityZ(1:NzNz,ind))/NzNz;
    ChargedensityZ(1:NzNz,ind)=-ChargedensityZ(1:NzNz,ind)+averageChargedensityZ;
    ChargedensityZ(1:NzNz,ind)=2*ChargedensityZ(1:NzNz,ind)./(phi0*Ny);  % Qz/(phi*e^2/2h)
    
    Lz=(NzNz-1)*a0;
    Polarization(:,ind)=sum(ChargedensityZ(1:NzNz,ind).*(-Lz/2:a0:Lz/2)')./Lz; % P/(phi*e^2/2h)
    Magnetoelectric(:,ind)=-Polarization(:,ind);  % Unit: e^2/2h.
    
    ChargedensityZNzNz=ChargedensityZ(1:NzNz,ind)
    PolarizationNzNz=Polarization(:,ind)
    MagnetoelectricNzNz=Magnetoelectric(:,ind)
    
    
    save(['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.mat'],...
        'M0','A1','A2','B1','B2','a0','Ny','Nz','Mz','phi0','Ef','eta','ChargedensityZ','Polarization','Magnetoelectric')
    
    figure,hold on,box on
    plot(1./((Nz-1)*a0),Magnetoelectric,'b-o')
    xlabel('1/L_z'),ylabel('-P/(\Phi\cdote^2/2h)')
    
    title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', M_z=',num2str(Mz)];
           ['N_y=',num2str(Ny),', \Phi_0=',num2str(phi0),' h/e',', E_f=',num2str(Ef),', \eta=',num2str(eta)]})
    
    saveas(gcf,['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.fig'])
    close(gcf)
    
    toc
end

open(['MagEleCoeffofSurfMagneticHighSpin32TIFilmwithFixedBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.fig'])

end