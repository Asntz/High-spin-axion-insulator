function ChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfield
format long

global M0 A1 A2 B1 B2 a0 Ny Nz Mz phi0 Ef eta

M0=1; A1=1; A2=1; B1=0.6; B2=0.6; a0=1;
Ny=40; Nz=24;
Mz=0.6;
phi0=0.01; % Unit h/e.
Ef=0;
eta=1.e-04;

tau0=eye(2); taux=[0,1;1,0]; tauy=[0,-1i;1i,0]; tauz=[1,0;0,-1];

s0=eye(4); sx=[0,sqrt(3),0,0;sqrt(3),0,2,0;0,2,0,sqrt(3);0,0,sqrt(3),0]/2;
sy=[0,sqrt(3),0,0;-sqrt(3),0,2,0;0,-2,0,sqrt(3);0,0,-sqrt(3),0]*complex(0.0,-0.5);
sz=[3/2,0,0,0;0,1/2,0,0;0,0,-1/2,0;0,0,0,-3/2];

Gamma1=kron(sx,taux); Gamma2=kron(sy,taux); Gamma3=kron(sz,taux);
Gamma4=kron(s0,tauz); Gamma5=kron(sz,tau0);
orbitnum=8;

Ti=(M0-2*B1/a0^2-4*B2/a0^2)*Gamma4;
Tx=B2/a0^2*Gamma4-1i*A2*Gamma1/(2*a0);
Ty=B2/a0^2*Gamma4-1i*A2*Gamma2/(2*a0);
Tz=B1/a0^2*Gamma4-1i*A1*Gamma3/(2*a0);
Ezm=Mz*Gamma5;


H00=kron(eye(Nz),kron(eye(Ny),Ti)+kron(diag(ones(Ny-1,1),1),Ty)+kron(diag(ones(Ny-1,1),-1),Ty'))+...
    kron(diag(ones(Nz-1,1),1),kron(eye(Ny),Tz))+kron(diag(ones(Nz-1,1),-1),kron(eye(Ny),Tz'))+...
    kron(diag([ones(Ny,1);zeros(Ny*(Nz-2),1);-ones(Ny,1)]),Ezm);
H01=kron(eye(Nz),kron(diag(exp(1i*2*pi*phi0*(1:Ny))),Tx));

H00nonmag=kron(eye(Nz),Ti)+kron(diag(ones(Nz-1,1),1),Tz)+kron(diag(ones(Nz-1,1),-1),Tz')+kron(diag([1;zeros(Nz-2,1);-1]),Ezm);
H01xnonmag=kron(eye(Nz),Tx);
H01ynonmag=kron(eye(Nz),Ty);


tic
ChernNumberZ=LocalChernNumberofSurfaceMagneticHighSpin32TIFilmwithBfield(H00nonmag,H01xnonmag,H01ynonmag);
ChernNumberZ
toc


tic
ChargedensityZ=integral(@(kx) IntofChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfield(kx,H00,H01),-pi/a0,pi/a0,'ArrayValued',true);
ChargedensityZ=ChargedensityZ.*a0./(2*pi);
toc

averageChargedensityZ=sum(ChargedensityZ)/Nz;
ChargedensityZ=-ChargedensityZ+averageChargedensityZ;
ChargedensityZ=2*ChargedensityZ./(phi0*Ny);   % Qz/(phi*e^2/2h)

Lz=(Nz-1)*a0;
Polarization=sum(ChargedensityZ.*(-Lz/2:a0:Lz/2)')./Lz; % P/(phi*e^2/2h)
Magnetoelectric=-Polarization;   % Unit: e^2/2h.

ChargedensityZ,Polarization,Magnetoelectric


save(['ChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.mat'],...
    'M0','A1','A2','B1','B2','a0','Ny','Nz','Mz','phi0','Ef','eta','ChargedensityZ','Polarization','Magnetoelectric','ChernNumberZ')


figure,hold on,box on
yyaxis left
plot((-Lz/2:a0:Lz/2)'./Lz,ChargedensityZ,'-s','DisplayName','Q_z')
xlabel('z/L_z')
ylabel('Q_z/(\Phi\cdote^2/2h)')
text(-0.5,-2,['\alpha^{slab}_{CS}\approx',num2str(Magnetoelectric),'e^2/2h',', \theta^{slab}_{CS}\approx',num2str(Magnetoelectric),'\pi'])

yyaxis right
plot((-Lz/2:a0:Lz/2)'./Lz,ChernNumberZ,'-^','DisplayName','C_z')
xlabel('z/L_z')
ylabel('C_z')

legend

title({['spin=3/2',', M_0=',num2str(M0),', A_1=',num2str(A1),', A_2=',num2str(A2),', B_1=',num2str(B1),', B_2=',num2str(B2),', a_0=',num2str(a0),', N_y=',num2str(Ny),', N_z=',num2str(Nz),', M_z=',num2str(Mz)];
    ['\Phi_0=(',num2str(phi0),') h/e',', E_f=',num2str(Ef),', \eta=',num2str(eta)]})


saveas(gcf,['ChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.fig'])
close(gcf)
open(['ChargeDistriofSurfaceMagneticHighSpin32TIFilmwithBfieldM0',num2str(M0),'A1',num2str(A1),'A2',num2str(A2),'B1',num2str(B1),'B2',num2str(B2),'a0',num2str(a0),'Ny',num2str(Ny),'Nz',num2str(Nz),'Mz',num2str(Mz),'phi0',num2str(phi0),'Ef',num2str(Ef),'eta',num2str(eta),'.fig'])

end